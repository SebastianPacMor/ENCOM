package formu;

import java.io.FileInputStream;
import java.sql.*;
import javax.swing.JOptionPane;

public class conexion
{
    Connection connect;
    final String URL = "jdbc:postgresql://127.0.0.1/Contenido";
    final String user = "postgres";
    final String password = "161219153";
    PreparedStatement pst;
    
    public conexion()
    {
        try
        {
            connect = DriverManager.getConnection(URL, user, password);
            System.out.println("Conexi\u00f3n a la base de datos realizada correctamente");
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error en la conexi\u00f3n a la base de datos:\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void addInfo(String titulo, String texto, FileInputStream img, int lb)
    {
        try
        {
            pst = connect.prepareStatement("INSERT INTO contenido (titulo, imagen, informacion) VALUES (?, ?, ?)");
            pst.setString(1, titulo);
            pst.setBinaryStream(2, img, lb);
            pst.setString(3, texto);
            pst.executeUpdate();
        }
        catch(SQLException sql)
        {
            JOptionPane.showMessageDialog(null, "Error al añadir: " + sql, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
