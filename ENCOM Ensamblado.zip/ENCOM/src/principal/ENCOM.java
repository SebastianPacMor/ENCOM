package principal;
import vistas.*;

/* @author ENCOM */

/*
\u00e1 -> á
\u00e9 -> é
\u00ed -> í
\u00f3 -> ó
\u00fa -> ú
\u00c1 -> A Tildada
\u00c9 -> É
\u00cd -> I Tildada
\u00d3 -> Ó
\u00da -> Ú
\u00f1 -> ñ
\u00d1 -> Ñ
*/

public class ENCOM
{
    public static void main(String[] args)
    {
        inicio_sesion nuevo = new inicio_sesion();
    }
}
