package conexion;

import javax.swing.JOptionPane;
import java.sql.*;

/* @author ENCOM */

public class usuarios
{
    final String URL = "jdbc:postgresql://127.0.0.1/Usuarios";
    final String user = "postgres";
    final String password = "161219153";
    Connection link;
    PreparedStatement pst;
    
    public usuarios()
    {
        try
        {
            link = DriverManager.getConnection(URL, user, password);
            System.out.println("Conexi\u00f3n establecida con 'Usuarios'");
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error en la conexi\u00f3n a la base de datos:\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean val_usuario(String user, String pass)
    {
        try
        {
            PreparedStatement pst = link.prepareStatement("SELECT * FROM crear_usuario WHERE usuario = ?");
            pst.setString(1, user);

            ResultSet b = pst.executeQuery();
            if(b.next())
            {
                if(b.getString("contraseña").equals(String.valueOf(pass)))
                {
                    return true;
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Incorrecta", JOptionPane.WARNING_MESSAGE);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Usuario no encontrado", "No encontrado", JOptionPane.WARNING_MESSAGE);
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, "Error : " + ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
    
    public String es_admin(String user)
    {
        String ADMIN = "";
        try
        {
            PreparedStatement pst = link.prepareStatement("SELECT * FROM crear_usuario WHERE usuario = ?");
            pst.setString(1, user);

            ResultSet b = pst.executeQuery();
            if(b.next())
            {
                ADMIN = b.getString("ADMIN");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Incorrecta", JOptionPane.WARNING_MESSAGE);

            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error : " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
        return ADMIN;
    }
    
    public boolean cr_usuario(String prin, String segn, String pria, String sega, String us, String pass, boolean adc)
    {
        String d;
        try
        {
            pst = link.prepareStatement("INSERT INTO crear_usuario (primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, usuario, contraseña, admin) VALUES (?, ?, ?, ?, ?, ?, ?)");
            pst.setString(1, prin);
            pst.setString(2, segn);
            pst.setString(3, pria);
            pst.setString(4, sega);
            pst.setString(5, us);
            pst.setString(6, pass);
            if(adc)
            {
                pst.setString(7, "SI");
                d = "Usuario administrador agregado con \u00e9xito";
            }
            else
            {
                pst.setString(7, "NO");
                d = "Usuario agregado con \u00e9xito";
            }
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, d, "Exito", JOptionPane.INFORMATION_MESSAGE);
        }
        catch(SQLException sql)
        {
            JOptionPane.showMessageDialog(null, "Error al añadir: " + sql, "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
    
}
