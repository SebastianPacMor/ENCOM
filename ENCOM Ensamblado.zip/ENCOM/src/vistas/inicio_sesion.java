package vistas;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import conexion.*;

/* @author ENCOM */

public final class inicio_sesion extends JFrame implements ActionListener
{
    usuarios reg = new usuarios();
    private final JLabel log, user, pass;
    private final JTextField us;
    private final JPasswordField pa;
    private final JButton start, ma;
    public inicio_sesion()
    {
        //JLabel Log-In
        log = new JLabel("ENCOM");
        log.setBackground(Color.WHITE);
        log.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 20));
        log.setForeground(Color.BLACK);
        log.setOpaque(true);
        log.setBounds(162, 30, 69, 27);
        add(log);

        //JLabel User
        user = new JLabel("Usuario");
        user.setBackground(Color.WHITE);
        user.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        user.setForeground(Color.BLACK);
        user.setOpaque(true);
        user.setBounds(40, 90, 60, 22);
        add(user);

        //JLabel Password
        pass = new JLabel("Contrase\u00f1a");
        pass.setBackground(Color.WHITE);
        pass.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        pass.setForeground(Color.BLACK);
        pass.setOpaque(true);
        pass.setBounds(40, 175, 90, 22);
        add(pass);

        //JTextField User
        us = new JTextField();
        us.setBounds(40, 120, 300, 22);
        add(us);

        //JPaswordField pass
        pa = new JPasswordField();
        pa.setBounds(40, 205, 300, 22);
        add(pa);

        //JButton Start
        start = new JButton("Iniciar");
        start.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        start.setBounds(162, 238, 77, 58);
        start.setBorderPainted(false);
        start.setContentAreaFilled(false);
        start.setHorizontalTextPosition(JButton.CENTER);
        start.setVerticalTextPosition(JButton.BOTTOM);
        start.setIcon(new ImageIcon(getClass().getResource("/recursos/startb.png")));
        start.setRolloverIcon(new ImageIcon(getClass().getResource("/recursos/startbr.png")));
        start.setPressedIcon(new ImageIcon(getClass().getResource("/recursos/startbp.png")));
        start.addActionListener(this);
        add(start);

        //JButton Crear cuenta
        ma = new JButton();
        ma.setBorderPainted(false);
        ma.setContentAreaFilled(false);
        ma.setVerticalAlignment(JButton.CENTER);
        ma.setHorizontalAlignment(JButton.CENTER);
        ma.setIcon(new ImageIcon(getClass().getResource("/recursos/crcb.png")));
        ma.setRolloverIcon(new ImageIcon(getClass().getResource("/recursos/crcbr.png")));
        ma.setPressedIcon(new ImageIcon(getClass().getResource("/recursos/crcbp.png")));
        ma.setBounds(150, 300, 100, 20);
        ma.setBackground(Color.WHITE);
        ma.addActionListener(this);
        add(ma);

        //Background
        JLabel bg = new JLabel(new ImageIcon(getClass().getResource("/recursos/bg.png")));
        bg.setBounds(0, 0, 400, 370);
        add(bg);

        //Frame
        setIconImage(new ImageIcon(getClass().getResource("/recursos/icon.png")).getImage());
        setTitle("Ingreso a ENCOM");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent ic)
    {
        if(ic.getSource() == start)
        {
            if((us.getText().equals("")) || (String.valueOf(pa.getPassword()).equals("")))
            {
                JOptionPane.showMessageDialog(null, "Campos vac\u00edos...", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                if(reg.val_usuario(us.getText(), String.valueOf(pa.getPassword())))
                {
                    JOptionPane.showMessageDialog(null, "Bienvenid\u0040 " + us.getText() +"\n\nes ud ADMIN? = " + reg.es_admin(us.getText()));
                    /*  Aquí va la declaración del la vista de buscar llamando el método:
                        bd1.es_admin(us.getText());
                    
                        Ese método envía a la otra vista si el usuario iniciado es ADMIN o no, para activar o desactivar la opcion de edición
                    */
                }
            }
        }    
        
        if(ic.getSource() == ma)
        {
            crear_cuenta nueva = new crear_cuenta();
        }
    }
}
