package vistas;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import conexion.*;

/* @author ENCOM */

public final class crear_cuenta extends JFrame implements ActionListener
{
    usuarios reg = new usuarios();
    private final JLabel Pnombre, Snombre, Papellido, Sapellido, user, con, titulo, adm;
    private final JTextField nombre1, nombre2, apellido1, apellido2, usuario;
    private final JPasswordField pase, cadm;
    private final JButton agregar, cancelar;
    public crear_cuenta()
    {
        //JLabel Titulo
        titulo=new JLabel("Nuevo Usuario ENCOM");
        titulo.setBackground(Color.WHITE);
        titulo.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        titulo.setForeground(Color.BLACK);
        titulo.setOpaque(true);
        titulo.setBounds(40, 30, 197, 27);
        add(titulo);

        //JLabel Primer Nombre1
        Pnombre = new JLabel("Primer Nombre");
        Pnombre.setBackground(Color.WHITE);
        Pnombre.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        Pnombre.setForeground(Color.BLACK);
        Pnombre.setOpaque(true);
        Pnombre.setBounds(40, 77, 147, 27);
        add(Pnombre);

        //JLabel Segundo Nombre2
        Snombre = new JLabel("Segundo Nombre");
        Snombre.setBackground(Color.WHITE);
        Snombre.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        Snombre.setForeground(Color.BLACK);
        Snombre.setOpaque(true);
        Snombre.setBounds(382, 77, 147, 27);
        add(Snombre);

        //JLabel Primer Apellido1
        Papellido = new JLabel("Primer Apellido");
        Papellido.setBackground(Color.WHITE);
        Papellido.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        Papellido.setForeground(Color.BLACK);
        Papellido.setOpaque(true);
        Papellido.setBounds(40, 180, 147, 27);
        add(Papellido);

        //JLabel Segundo Apellido2
        Sapellido = new JLabel("Segundo Apellido");
        Sapellido.setBackground(Color.WHITE);
        Sapellido.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        Sapellido.setForeground(Color.BLACK);
        Sapellido.setOpaque(true);
        Sapellido.setBounds(382, 180, 147, 27);
        add(Sapellido);

        //JLabel usuario
        user = new JLabel("Usuario");
        user.setBackground(Color.WHITE);
        user.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        user.setForeground(Color.BLACK);
        user.setOpaque(true);
        user.setBounds(40, 275, 98, 22);
        add(user);

        //JLabel contraseña
        con = new JLabel("Contrase\u00f1a");
        con.setBackground(Color.WHITE);
        con.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        con.setForeground(Color.BLACK);
        con.setOpaque(true);
        con.setBounds(382, 275, 128, 22);
        add(con);
        
        //JLabel admin pass
        adm = new JLabel("ADMIN:");
        adm.setBackground(Color.WHITE);
        adm.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        adm.setForeground(Color.BLACK);
        adm.setOpaque(true);
        adm.setBounds(382, 30, 55, 22);
        add(adm);

        //JPaswordField cadmin
        cadm = new JPasswordField();
        cadm.setBounds(439, 30, 80, 22);
        add(cadm);
        
        //JTextField usuario
        usuario = new JTextField();
        usuario.setBounds(40, 305, 250, 22);
        add(usuario);

        //JTextField primer nombre
        nombre1 = new JTextField();
        nombre1.setBounds(40, 120, 250, 22);
        add(nombre1);

        //JTextField segundo nombre
        nombre2 = new JTextField();
        nombre2.setBounds(382, 120, 250, 22);
        add(nombre2);

        //JTextField primer apellido
        apellido1 = new JTextField();
        apellido1.setBounds(40, 215, 250, 22);
        add(apellido1);

        //JTextField segundo apellido
        apellido2 = new JTextField();
        apellido2.setBounds(382, 215, 250, 22);
        add(apellido2);

        //JPaswordField contraseña
        pase = new JPasswordField();
        pase.setBounds(382, 305, 250, 22);
        add(pase);

        //JButton agregar
        agregar = new JButton("Agregar Usuario");
        agregar.setBorderPainted(false);
        agregar.setContentAreaFilled(false);
        agregar.setVerticalAlignment(JButton.CENTER);
        agregar.setHorizontalAlignment(JButton.CENTER);
        agregar.setIcon(new ImageIcon(getClass().getResource("/recursos/crearb.png")));
        agregar.setRolloverIcon(new ImageIcon(getClass().getResource("/recursos/crearbr.png")));
        agregar.setPressedIcon(new ImageIcon(getClass().getResource("/recursos/crearbp.png")));
        agregar.setBounds(60, 350, 250, 30);
        agregar.setBackground(Color.WHITE);
        agregar.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        agregar.addActionListener(this);
        add(agregar);

        //JButton Cancelar
        cancelar = new JButton("Cancelar");
        cancelar.setBorderPainted(false);
        cancelar.setContentAreaFilled(false);
        cancelar.setVerticalAlignment(JButton.CENTER);
        cancelar.setHorizontalAlignment(JButton.CENTER);
        cancelar.setIcon(new ImageIcon(getClass().getResource("/recursos/cancelarb.png")));
        cancelar.setRolloverIcon(new ImageIcon(getClass().getResource("/recursos/cancelarbr.png")));
        cancelar.setPressedIcon(new ImageIcon(getClass().getResource("/recursos/cancelarbp.png")));
        cancelar.setBounds(390, 350, 150, 35);
        cancelar.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 15));
        cancelar.setBackground(Color.WHITE);
        cancelar.addActionListener(this);
        add(cancelar);

        //Background
        JLabel fondo = new JLabel(new ImageIcon(getClass().getResource("/recursos/FondoProyecto.jpg")));
        fondo.setBounds(0, 0, 700, 500);
        add(fondo);

        //Frame
        setIconImage(new ImageIcon(getClass().getResource("/recursos/icon.png")).getImage());
        setTitle("Cuenta ENCOM");
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setSize(680, 500);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        this.control_letras(nombre1);
        this.control_letras(nombre2);
        this.control_letras(apellido1);
        this.control_letras(apellido2);
    }
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == cancelar)
        {
            dispose();
        }
        
        if(e.getSource() == agregar)
        {
            boolean pa;
            if((nombre1.getText().equals("")) || (apellido1.getText().equals("")) || (apellido2.getText().equals("")) || (usuario.getText().equals("")) || (String.valueOf(pase.getPassword()).equals("")))
            {
                JOptionPane.showMessageDialog(null, "Campos vac\u00edos...", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                if(String.valueOf(cadm.getPassword()).equals("\u0045\u004e\u0043\u0041\u0044\u004d"))
                {
                    pa = true;
                }
                else
                {
                    pa = false;
                }
                reg.cr_usuario(nombre1.getText(), nombre2.getText(), apellido1.getText(), apellido2.getText(), usuario.getText(), String.valueOf(pase.getPassword()), pa);
                nombre1.setText("");
                nombre2.setText("");
                apellido1.setText("");
                apellido2.setText("");
                usuario.setText("");
                pase.setText("");
                cadm.setText("");
            }
        }
    }
    
    public void control_letras(JTextField caja)
    {
        caja.addKeyListener(new KeyListener()
        {
            @Override
            public void keyTyped(KeyEvent ke)
            {
                char c = ke.getKeyChar();
                if (Character.isDigit(c))
                {
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "Caracteres no permitidos", "Advertencia", JOptionPane.WARNING_MESSAGE);
                }
            }

            @Override
            public void keyPressed(KeyEvent ke) {

            }

            @Override
            public void keyReleased(KeyEvent ke) {

            }
        });
    }
}
