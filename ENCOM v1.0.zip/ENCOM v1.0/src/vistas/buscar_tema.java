package vistas;

import conexion.cola;
import conexion.contenido;
import static conexion.contenido.conectar;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/* @author ENCOM */

public class buscar_tema extends javax.swing.JFrame
{
    int contador = 0;
    DefaultComboBoxModel busquedas;
    contenido nuevo = new contenido();
    cola busq = new cola();
    String[] opciones = busq.getBusq();
    Dimension scr_size = Toolkit.getDefaultToolkit().getScreenSize();
    String ADMIN, usuarion;
    int anch = (((int) scr_size.getWidth() / 2) - (530 / 2));
    int lar = (((int) scr_size.getHeight() / 2) - (250 / 2));
    public buscar_tema(String ad, String n)
    {
        
        ADMIN = ad;
        usuarion = n;
        initComponents();
        this.setLocationRelativeTo(null);
        try{
            DefaultTableModel modelo= new DefaultTableModel();
            Tabla.setModel(modelo);
            PreparedStatement ps=null;
            ResultSet rs=null;
            Connection con= conectar();
            String SQL="SELECT titulo From contenido";
            ps= con.prepareStatement(SQL);
            rs=ps.executeQuery();
            ResultSetMetaData rsm=rs.getMetaData();
            int Cant=rsm.getColumnCount();
            modelo.addColumn("ENCOM "+"Enciclopedia Computacional");
            while(rs.next()){
                Object [] filas= new Object[Cant];
                for(int i=0;i<Cant;i++){
                    filas[i]=rs.getObject(i+1);
                }
                modelo.addRow(filas);
            }
            
            
        }
        catch(SQLException e)
        {
            System.out.println(e);
        }
    }
  
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fond = new bgr();
        jPanel2 = new javax.swing.JPanel();
        agregar = new javax.swing.JButton();
        if(ADMIN.equals("SI"))
        {
            agregar.setVisible(true);
        }
        else
        {
            agregar.setVisible(false);
        }
        salir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        icono = new javax.swing.JLabel();
        buscar = new javax.swing.JButton();
        buscarL = new javax.swing.JLabel();
        busqueda = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        AMD = new javax.swing.JLabel();
        Gates = new javax.swing.JLabel();
        Computadora = new javax.swing.JLabel();
        Software = new javax.swing.JLabel();
        AMD2 = new javax.swing.JLabel();
        Gates2 = new javax.swing.JLabel();
        Software2 = new javax.swing.JLabel();
        Computadora2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        Caja = new JComboBox<>(opciones);
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ENCOM, busca tu artículo");
        setLocation(anch, lar);
        setUndecorated(true);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/addb.png"))); // NOI18N
        agregar.setBorder(null);
        agregar.setBorderPainted(false);
        agregar.setContentAreaFilled(false);
        agregar.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/addbp.png"))); // NOI18N
        agregar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/addbr.png"))); // NOI18N
        agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarActionPerformed(evt);
            }
        });

        salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/exitb.png"))); // NOI18N
        salir.setBorder(null);
        salir.setBorderPainted(false);
        salir.setContentAreaFilled(false);
        salir.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/exitbp.png"))); // NOI18N
        salir.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/exitbr.png"))); // NOI18N
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 16)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Bienvenid\u0040, " + usuarion);

        icono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/icon2.png"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(icono)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(agregar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(salir)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(agregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(salir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(icono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/searchb.png"))); // NOI18N
        buscar.setBorder(null);
        buscar.setBorderPainted(false);
        buscar.setContentAreaFilled(false);
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        buscarL.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        buscarL.setText("Buscar artículo:");

        busqueda.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        busqueda.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel3.setText("Quizas te pueda interesar");

        AMD.setText("imagen");
        AMD.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));
        AMD.setMaximumSize(new java.awt.Dimension(30, 17));
        AMD.setMinimumSize(new java.awt.Dimension(30, 17));
        AMD.setPreferredSize(new java.awt.Dimension(30, 17));

        Gates.setText("imagen");
        Gates.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));
        Gates.setMaximumSize(new java.awt.Dimension(30, 17));
        Gates.setMinimumSize(new java.awt.Dimension(30, 17));
        Gates.setPreferredSize(new java.awt.Dimension(30, 17));

        Computadora.setText("imagen");
        Computadora.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));
        Computadora.setMaximumSize(new java.awt.Dimension(30, 17));
        Computadora.setMinimumSize(new java.awt.Dimension(30, 17));
        Computadora.setPreferredSize(new java.awt.Dimension(30, 17));

        Software.setText("imagen");
        Software.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));
        Software.setMaximumSize(new java.awt.Dimension(30, 17));
        Software.setMinimumSize(new java.awt.Dimension(30, 17));
        Software.setPreferredSize(new java.awt.Dimension(30, 17));

        AMD2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        AMD2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        Gates2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        Gates2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        Software2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        Software2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        Computadora2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        Computadora2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        jLabel4.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel4.setText("Encuentra aqui todos nuestros temas...");

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "ENCOM \"Enciclopedia Computacional\""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla);
        if (Tabla.getColumnModel().getColumnCount() > 0) {
            Tabla.getColumnModel().getColumn(0).setResizable(false);
        }

        Caja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CajaActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 12)); // NOI18N
        jLabel2.setText("Búsquedas recientes:");

        javax.swing.GroupLayout fondLayout = new javax.swing.GroupLayout(fond);
        fond.setLayout(fondLayout);
        fondLayout.setHorizontalGroup(
            fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(fondLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(buscarL)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(busqueda)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(buscar)
                .addGap(8, 8, 8))
            .addGroup(fondLayout.createSequentialGroup()
                .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3))
                    .addGroup(fondLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addGroup(fondLayout.createSequentialGroup()
                                .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(AMD2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(AMD, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Gates2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(fondLayout.createSequentialGroup()
                                        .addComponent(Gates, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Computadora, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Computadora2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Software2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Software, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 818, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 26, Short.MAX_VALUE))
            .addGroup(fondLayout.createSequentialGroup()
                .addGap(300, 300, 300)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Caja, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        fondLayout.setVerticalGroup(
            fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fondLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(buscarL, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(busqueda, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
                    .addComponent(buscar))
                .addGap(18, 18, 18)
                .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(fondLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(AMD, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Gates, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Computadora, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Software, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AMD2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Computadora2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Gates2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Software2, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(fondLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Caja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(fondLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(5, 5, 5)))
                .addGap(271, 271, 271))
        );

        Caja.getAccessibleContext().setAccessibleName("BUSQUEDAS RECIENTES");
        Caja.getAccessibleContext().setAccessibleDescription("Bus");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(fond, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(fond, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 584, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_salirActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        if(contador < 5)
        {
            busq.insertar(busqueda.getText(), contador);
            Caja.removeAllItems();
            for(int c = 0; c < 5; c++)
            {
                Caja.addItem(busq.getDato(c));
            }
            contador++;
            Caja.updateUI();
        }
        else
        {
            contador = busq.desplazar(contador);
            busq.insertar(busqueda.getText(), contador);
            Caja.removeAllItems();
            for(int c = 0; c < 5; c++)
            {
                Caja.addItem(busq.getDato(c));
            }
            contador++;
            Caja.updateUI();
        }
        mostrar_tema art = new mostrar_tema(busqueda.getText());
        art.setVisible(true);
    }//GEN-LAST:event_buscarActionPerformed

    private void agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarActionPerformed
        insertar_tema nuevot = new insertar_tema();
        nuevot.setVisible(true);
    }//GEN-LAST:event_agregarActionPerformed

    private void CajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CajaActionPerformed
        
    }//GEN-LAST:event_CajaActionPerformed

    public static void main(String args[])
    {
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Metal".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(buscar_tema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(buscar_tema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(buscar_tema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(buscar_tema.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

    }
    /*public void Listar() {
        contenido conexion= new contenido();
        Connection Connection = conectar();
        String sql=" SELECT titulo FROM contenido";
        Statement rs;
        DefaultTableModel modelo= new DefaultTableModel();
        Tabla.setModel(modelo);
        String[] dato = new String[1];
        try{
            rs= Connection.prepareStatement(sql);
            ResultSet r2= rs.executeQuery(sql);
            while(r2.next()){
                System.out.println(r2.getString(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(buscar_tema.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AMD;
    private javax.swing.JLabel AMD2;
    private javax.swing.JComboBox<String> Caja;
    private javax.swing.JLabel Computadora;
    private javax.swing.JLabel Computadora2;
    private javax.swing.JLabel Gates;
    private javax.swing.JLabel Gates2;
    private javax.swing.JLabel Software;
    private javax.swing.JLabel Software2;
    private javax.swing.JTable Tabla;
    private javax.swing.JButton agregar;
    private javax.swing.JButton buscar;
    private javax.swing.JLabel buscarL;
    private javax.swing.JTextField busqueda;
    private javax.swing.JPanel fond;
    private javax.swing.JLabel icono;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton salir;
    // End of variables declaration//GEN-END:variables
    class bgr extends JPanel
    {
        private Image imagen;
        @Override
        public void paint(Graphics g)
        {
            imagen= new ImageIcon(getClass().getResource("/recursos/buscbg.png")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            nuevo.mostrar_cont("AMD");
            AMD.setIcon(nuevo.getImagen());
            AMD2.setText(nuevo.getTitulo());
            nuevo.mostrar_cont("Bill Gates");
            Gates.setIcon(nuevo.getImagen());
            Gates2.setText(nuevo.getTitulo());
            nuevo.mostrar_cont("La Primera Computadora");
            Computadora.setIcon(nuevo.getImagen());
            Computadora2.setText(nuevo.getTitulo());
            nuevo.mostrar_cont("Software");
            Software.setIcon(nuevo.getImagen());
            Software2.setText(nuevo.getTitulo());
            super.paint(g);
        }
    }

}
