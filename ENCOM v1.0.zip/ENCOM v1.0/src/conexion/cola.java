package conexion;

import javax.swing.*;

/* @author ENCOM */

public class cola
{
    String[] busq = new String[5];
    
    public cola()
    {
        for(int c = 0; c < 5; c++)
        {
            busq[c] = "";
        }
    }
    
    public String[] getBusq()
    {
        return busq;
    }
    
    public void insertar(String d, int esp)
    {
        try
        {
            busq[esp] = d;
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            JOptionPane.showMessageDialog(null, "No hay espacio para agregar elementos a la cola...", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public int desplazar(int cont)
    {
        int caux = cont -1;
        String[]co2 = busq;
        busq = new String[5];
        for(int c = 0; c < 5; c++)
        {
            busq[c] = "";
        }
        int c = 0;
        while((getDato(c).equals("")) && (c < 4))
        {
            {
                busq[c] = co2[c+1];
                c++;
            }
        }
        return caux;
    }
    
    public String getDato(int esp)
    {
        return busq[esp];
    }
}
