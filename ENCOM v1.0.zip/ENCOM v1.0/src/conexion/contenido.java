package conexion;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/* @author ENCOM */

public class contenido
{
    static final String URL = "jdbc:postgresql://127.0.0.1/Contenido";
    static final String user = "postgres";
    static final String password = "161219153";
    static Connection link;
    PreparedStatement pst;
    String ti, te;
    ImageIcon im;
    
    public static Connection conectar()
    {
        try
        {
            link = DriverManager.getConnection(URL, user, password);
            System.out.println("Conexi\u00f3n establecida con 'Contenido'");
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error en la conexi\u00f3n a la base de datos:\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
        return link;
    }
    
    public void agregar_cont(String titulo, String texto, FileInputStream img, int lb)
    {
        try
        {
            pst = link.prepareStatement("INSERT INTO contenido (titulo, imagen, informacion) VALUES (?, ?, ?)");
            pst.setString(1, titulo);
            pst.setBinaryStream(2, img, lb);
            pst.setString(3, texto);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Art\u00edculo agregado correctamente", "Agregado", JOptionPane.INFORMATION_MESSAGE);
        }
        catch(SQLException sql)
        {
            JOptionPane.showMessageDialog(null, "Error al añadir: " + sql, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void mostrar_cont(String t)
    {
        try
        {
            pst = link.prepareStatement("select * from contenido where titulo=?");
            pst.setString(1, t);
            ImageIcon foto;
            InputStream is;
            String title, information;
            try
            {
                ResultSet rs = pst.executeQuery();
                while(rs.next())
                {
                    title = rs.getString(1);
                    //System.out.println(title);
                    is = rs.getBinaryStream(2);
                    information = rs.getString(3);

                    BufferedImage bi = ImageIO.read(is);
                    foto = new ImageIcon(bi);

                    Image img = foto.getImage();
                    Image newimg = img.getScaledInstance(220, 220, java.awt.Image.SCALE_SMOOTH);

                    ImageIcon newicon = new ImageIcon(newimg);

                    ti = title;
                    im = newicon;
                    te = information;
                }
            }
            catch(IOException | SQLException ex)
            {
                JOptionPane.showMessageDialog(null, "Error al obtener datos: " + ex, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error al obtener datos: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }    
    
    
    public String getTitulo()
    {
        return ti;
    }

    public String getTexto()
    {
        return te;
    }

    public ImageIcon getImagen()
    {
        return im;
    }
}
