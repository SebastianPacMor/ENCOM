package bdc;

import javax.swing.JOptionPane;
import java.sql.*;
import org.postgresql.Driver;
import org.postgresql.jdbc.*;
import org.postgresql.jdbc2.*;
import org.postgresql.jdbc3.*;
import org.postgresql.util.*;

/* @author ENCOM */

public class Usuarios
{
    final String URL = "jdbc:postgresql://127.0.0.1/Usuarios";
    final String user = "postgres";
    final String password = "161219153";
    Connection link;
    
    public Usuarios()
    {
        try
        {
            link = DriverManager.getConnection(URL, user, password);
            System.out.println("Conexi\u00f3n a la base de datos realizada correctamente");
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error en la conexi\u00f3n a la base de datos:\n" + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean val_user(String user, String pass)
    {
        try
        {
            PreparedStatement pst = link.prepareStatement("SELECT * FROM crear_usuario WHERE usuario = ?");
            pst.setString(1, user);

            ResultSet b = pst.executeQuery();
            if(b.next())
            {
                if(b.getString("contraseña").equals(String.valueOf(pass)))
                {
                    return true;
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Incorrecta", JOptionPane.WARNING_MESSAGE);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Usuario no encontrado", "No encontrado", JOptionPane.WARNING_MESSAGE);
            }
        }
        catch(SQLException ex)
        {
            JOptionPane.showMessageDialog(null, "Error : " + ex, "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }
    
    public String es_admin(String user)
    {
        String ADMIN = "";
        try
        {
            PreparedStatement pst = link.prepareStatement("SELECT * FROM crear_usuario WHERE usuario = ?");
            pst.setString(1, user);

            ResultSet b = pst.executeQuery();
            if(b.next())
            {
                ADMIN = b.getString("ADMIN");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Contraseña incorrecta", "Incorrecta", JOptionPane.WARNING_MESSAGE);

            }
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Error : " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
        return ADMIN;
    }
}
