package bdc;

import java.sql.*;
import org.postgresql.Driver;
import org.postgresql.jdbc.*;
import org.postgresql.jdbc2.*;
import org.postgresql.jdbc3.*;
import org.postgresql.util.*;

/* @author ENCOM */

public class Info
{
    
}
