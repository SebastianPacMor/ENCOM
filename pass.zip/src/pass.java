import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;

/*
\u00e1 -> á
\u00e9 -> é
\u00ed -> í
\u00f3 -> ó
\u00fa -> ú
\u00c1 -> A Tildada
\u00c9 -> É
\u00cd -> I Tildada
\u00d3 -> Ó
\u00da -> Ú
\u00f1 -> ñ
\u00d1 -> Ñ
*/

/* @author Sebastián Pachón Morales */

public final class pass extends JFrame implements ActionListener
{
    private final JLabel log, user, pass;
    private final JTextField us;
    private final JPasswordField pa;
    private final JButton start, ma;
    public pass()
    {
        //JLabel Log-In
        log = new JLabel("Log-in");
        log.setBackground(Color.BLACK);
        log.setFont(new Font("Verdana", Font.PLAIN, 20));
        log.setForeground(Color.WHITE);
        log.setOpaque(true);
        log.setBounds(115, 15, 62, 27);
        add(log);
        
        //JLabel User
        user = new JLabel("User");
        user.setBackground(Color.BLACK);
        user.setFont(new Font("Verdana", Font.BOLD, 15));
        user.setForeground(Color.WHITE);
        user.setOpaque(true);
        user.setBounds(23, 60, 39, 22);
        add(user);
        
        //JLabel User
        pass = new JLabel("Password");
        pass.setBackground(Color.BLACK);
        pass.setFont(new Font("Verdana", Font.BOLD, 15));
        pass.setForeground(Color.WHITE);
        pass.setOpaque(true);
        pass.setBounds(23, 135, 82, 22);
        add(pass);
        
        //JTextField User
        us = new JTextField();
        us.setBounds(23, 95, 238, 22);
        add(us);
        
        //JPaswordField pass
        pa = new JPasswordField();
        pa.setBounds(23, 170, 238, 22);
        add(pa);
        
        //JButton Start
        start = new JButton("Start");
        start.setBounds(70, 205, 67, 30);
        start.setBackground(Color.WHITE);
        start.addActionListener(this);
        add(start);
        
        //JButton Start
        ma = new JButton("Admin");
        ma.setBounds(150, 205, 67, 30);
        ma.setBackground(Color.WHITE);
        ma.addActionListener(this);
        add(ma);
        
        //Background
        JLabel bg = new JLabel(new ImageIcon(getClass().getResource("/recursos/bg.png")));
        bg.setBounds(0, 0, 300, 300);
        add(bg);
        
        //Frame
        setTitle("Log-In");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }
    
    public static void main(String args[])
    {
        pass p1 = new pass();
    }
    
    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == start)
        {
            if((us.getText().equals("")) || (String.valueOf(pa.getPassword()).equals("")))
            {
                JOptionPane.showMessageDialog(null, "Campos vac\u00edos...", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                if((us.getText().equals("admin")) && (String.valueOf(pa.getPassword()).equals("admin")))
                {
                    us.setText("");
                    pa.setText("");
                    JOptionPane.showMessageDialog(null, "Acceso satisfactorio...", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos...", "Warning", JOptionPane.WARNING_MESSAGE);
                }
            }
        }
        
        if(e.getSource() == ma)
        {
            if(String.valueOf(JOptionPane.showInputDialog(null, "Digite contraseña de administrador: ")).equals("1234"))
            {
                JOptionPane.showMessageDialog(null, "Ahora es administrador :D ", "Administrador", JOptionPane.INFORMATION_MESSAGE);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Contrase\u00f1a incorrecta", "Incorrecto", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}